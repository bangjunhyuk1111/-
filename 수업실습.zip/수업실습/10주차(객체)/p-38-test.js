console.log('#test.js파일')
const sample = 10